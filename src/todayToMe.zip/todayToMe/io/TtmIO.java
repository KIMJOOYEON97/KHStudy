package todayToMe.io;

public class TtmIO {

	//점수를 넘겨 받음.
	public void insertPoint(int num) {
		// TODO Auto-generated method stub
		
	}

	//총 점수를 넘겨줌
	public int loadPoint() {
		// TODO Auto-generated method stub
		return 0;
	}

}
