package todayToMe.controller;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import todayToMe.io.TtmIO;
import todayToMe.util.ChangePanel;
import todayToMe.util.SetBackground;
import todayToMe.util.TtmUtil;
import todayToMe.view.TtmMainview;

public class TtmController {

	//입력출력클래스 필드로 선언
	private TtmIO ttmIO = new TtmIO();
	
	public void changeView1 extends JPanel {
		
		private JFrame parent;
		public TtmController(JFrame parent, Color c, String title) {
			this.parent = parent; 
			
			new SetBackground(300, 400, title);
			setLayout(new BorderLayout());
			add(new JLabel(title), BorderLayout.NORTH);
			
			JPanel linkPanel = new JPanel();
			JButton answear1 = new JButton("1"); //이 버튼을 누르면 다음 패널로 넘어가려고 
			JButton answear2 = new JButton("2"); 
			JButton answear3 = new JButton("3");
			linkPanel.add(answear1);
			linkPanel.add(answear2);
			linkPanel.add(answear3);
			add(linkPanel, BorderLayout.SOUTH);
			
			//각 버튼별 패널교체하기
			ActionListener listener = new ActionListener() {
				
				@Override
				public void actionPerformed(ActionEvent e) {
					int index = Integer.parseInt(((JButton)e.getSource()).getText()); 
							//e.getSource()=>어디로부터 이벤트가 발생했는지 알 수 있음
					System.out.println(index);
					JPanel nextPanel = TtmMainview.panels; //MainFrame의 panels의 index번지를 참조함
					TtmUtil.changePanel(parent,ChangePanel.this,nextPanel); //여기서 this는 내부클래스 ActionListener객체로 넘어간다
					//부모 컨테이너에게 이 패널로 바꾸어달라고 해야함
					
				}
			};
			
			answear1.addActionListener(listener);
			answear2.addActionListener(listener);
			answear3.addActionListener(listener);
			
		}
	}

}
