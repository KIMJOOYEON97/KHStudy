package todayToMe.run;

public class TtmRun {
	//메인 Run
	public static void main(String[] args) {
		
	}

}
