package todayToMe.view;

import javax.swing.JFrame;
import javax.swing.JPanel;

import todayToMe.controller.TtmController;
import todayToMe.util.ChangePanel;
import todayToMe.util.TtmUtil;

//사용자에게 맨 처음 보여지는 화면
public class TtmMainview extends JFrame{
						
	//클릭하면 바뀔 화면
	public static ChangePanel panels = new ChangePanel();
	
	
	
	
	public TtmMainview(int w, int h,String title) {
		TtmUtil.init(this, w, h, title);
		
				//c부분에 이미지가 들어가면 된다.
		panels = new ChangePanel(this,c, title);
		
		add(panels);
		
		
	}
	
}
